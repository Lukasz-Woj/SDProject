<?php

//Linking TCPDF
require_once('TCPDF/tcpdf.php');

/* GRAB VALUES */

//Dane klienta
$imie = $_POST['imie'];
$nazwisko = $_POST['nazwisko'];
$nzwFirmy = $_POST['nazwa_firmy'];
$NIPfirmy = $_POST['NIP_firmy'];
$telefon = $_POST['telefon'];
$email = $_POST['email'];
//Funkcjonalnosc strony
$responsywna = $_POST['responsywna'];
$chatFb = $_POST['chat'];
$socialMedia = $_POST['social_media'];
$sklepInternetowy = $_POST['sklep'];
$wersjeJezykowe = $_POST['wersjejezykowe'];
$ruchNaStronie = $_POST['ruch'];
//Twoja strona WWW
$adresStrony = $_POST['adres'];
$rodzajStrony = $_POST['rodzajstrony'];
//$logoStrony = $_POST['']; //plik
$iloscPodstron = $_POST['ilosc'];
$adresDomeny = $_POST['adres_domeny'];
$oprogramowanieStrony = $_POST['oprogramowanie'];
$nazwyZakladek = $_POST['nazwyzakladek'];
//Dodatkowe uslugi
$hostingDomeny = $_POST['hosting'];
$Serwer = $_POST['serwer'];
$towrzenieGrafik = $_POST['grafiki'];
$domena = $_POST['domena'];
$obrobkaMaterialow = $_POST['obrobka'];
//Dodatkowe informacje o stronie
$opisWygladu = $_POST['opiswygladu'];
$uwagi = $_POST['uwagi'];
$linkiDoStron = $_POST['linkidostron'];

//Creating PDF
$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);

$pdf->AddPage('P', 'A4');

$content = <<<EOD
<h1> DANE FORMULARZA:</h1>
<h3> Dane Klienta </h3>
<h4> Imie: $imie </h4>
<h4> Nazwisko: $nazwisko </h4>
<h4> Nazwa firmy: $nzwFirmy </h4>
<h4> NIP firmy: $NIPfirmy </h4>
<h4> Telefon: $telefon </h4>
<h4> Adres email: $email </h4>

<h3> Funkcjonalnosc Strony </h3>
<h4> Responsywna: $responsywna </h4>
<h4> Chat Facebook: $chatFb </h4>
<h4> Social Media: $socialMedia </h4>
<h4> Sklep Internetowy: $sklepInternetowy </h4>
<h4> Wersje Jezykowe: $wersjeJezykowe </h4>
<h4> Ruch na stronie: $ruchNaStronie </h4>

<h3> Twoja strona WWW </h3>

<h3> Dodatkowe Uslugi </h3>

<h3> Dodatkowe informacje o stronie </h3>

EOD;

$pdf->writeHTML($content);

//Download PDF
$pdf->Output('DaneFormularza.pdf','D');

?>
