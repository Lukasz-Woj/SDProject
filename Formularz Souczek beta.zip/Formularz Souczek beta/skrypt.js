
var but = document.getElementById("but");
var imie = document.getElementById("name");
var nazwisko = document.getElementById("surname");
var nazwaFirmy = document.getElementById("firma");
var NIP = document.getElementById("NIP");
var telefon = document.getElementById("Tel");
var mail = document.getElementById("mail");

var AdrDom = document.getElementById("ADdom");
var Logo = document.getElementById("Logo");
var AdrStr = document.getElementById("ADstr");
var ChatTak = document.getElementById("Ctak");
var SocMedTak = document.getElementById("SMtak");
var SklTak = document.getElementById("SKtak");
var JezTak = document.getElementById("Jtak");
var Jezang = document.getElementById("jezang");
var Jezniem = document.getElementById("jezniem");
var Jezfran = document.getElementById("jezfran");
var RespTak = document.getElementById("Rtak");
var HostTak = document.getElementById("Htak");
var ServTak= document.getElementById("Stak");
var GrafTak= document.getElementById("Gtak");
var DomTak= document.getElementById("Dtak");
var ObrTak= document.getElementById("Otak");
var IloscPodstr = document.getElementById("iloscStron");


var cenaResponsywna = 200;
var cenaJezyk = 200;
var cenaSklepInternetowy = 200;
var cenaSocialMedia = 200;
var cenaChatFB = 200;
var cenaHosting = 200;
var cenaSerwer = 200;
var cenaGrafZaw = 200;
var cenaDomeny = 20000;
var cenaObrobka = 200;
var cenaPodstr = 200;

function waliduj(){
	const wImie = /[a-z]/;
	const wNIP = /PL[0-9]{3}\s[0-9]{6}\s[0-9]{1}/;
	const wTel = /[0-9]{9}/;
	
	if(wImie.test(imie.value) == false){
		alert("Zle imię");
	}
	
	if(wImie.test(nazwisko.value) == false){
		alert("Zle imię");
	}
	
	if(wNIP.test(NIP.value) == false){
		alert("Zly NIP");
	}
	
	
	if(wTel.test(telefon.value) == false){
		alert("Zly numer telefonu");
	}	
}

function obliczCene(){
	alert("hej");
	var cena = 0;
	cena += (parseInt(IloscPodstr.value) * cenaPodstr);
	
	if(RespTak.checked){
		cena += cenaResponsywna;
	}
	
	if(JezTak.checked){
		if(jezang.checked){
		cena += cenaJezyk;
		}
		if(Jezniem.checked){
		cena += cenaJezyk;
		}
		if(Jezfran.checked){
		cena += cenaJezyk;
		}
	}
	
	if(SklTak.checked){
		cena += cenaSklepInternetowy;
	}
	
	if(SocMedTak.checked){
		cena += cenaSocialMedia;
	}
	
	if(ChatTak.checked){
		cena += cenaChatFB;
	}
	
	if(HostTak.checked){
		cena += cenaHosting;
	}
	
	if(ServTak.checked){
		cena += cenaSerwer;
	}
	
	if(GrafTak.checked){
		cena += cenaGrafZaw;
	}
	
	if(DomTak.checked){
		cena += cenaDomeny;
	}
	
	if(ObrTak.checked){
		cena += cenaObrobka;
		
	}
	
	alert(cena);
}

but.onclick = obliczCene;

function pokazjezyki(){
	var jezyk = document.getElementById("language");
	jezyk.style.display = 'block';
}

function ukryjjezyki(){
	var jezyk = document.getElementById("language");
	jezyk.style.display = 'none';
}
