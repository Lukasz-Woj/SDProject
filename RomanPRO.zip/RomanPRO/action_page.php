<?php

//Linking PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

//Linking TCPDF
require_once('TCPDF/tcpdf.php');

//Grab values
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$message = $_POST['message'];

//Creating PDF
$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);

$pdf->AddPage('P', 'A4');

$content = <<<EOD
<h1> Your form data:</h1>
<h4> First name: $fname </h4>
<h4> Last name: $lname </h4>
<h4> Email: $email </h4>
<h4> Message: </h4>
<p> $message </p> 
EOD;

$pdf->writeHTML($content);

//PDF to String
$filledPdf = $pdf->Output('form.pdf', 'S');

//Download PDF
$pdf->Output('form.pdf','D');

//Mail settings
$mail = new PHPMailer(true);

    try {
        //Server settings
        // $mail->SMTPDebug = 2;
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'rromanowski291@gmail.com';         //SMTP username
        $mail->Password   = 'tyghbn12#4';                       //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        //Recipients
        $mail->setFrom('testmail@mail.com', 'Form');
        $mail->addAddress($email, 'Mailer');

        //Attachments
        $mail->addStringAttachment($filledPdf, 'yourForm.pdf');

        //Content
        $mail->isHTML(true);
        $mail->Subject = "Here is your form $fname";
        $mail->Body    = "<b> Thank you for using our site! </b>";
        $mail->AltBody = 'Thank you for using our site!';

        $mail->send();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }

    include 'afterPage.html';