<?php

//Linking TCPDF
require_once('TCPDF/tcpdf.php');

//Linking PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

//---------------------
/* GRAB VALUES */
//---------------------

//Dane klienta
$imie = $_POST['imie'];
$nazwisko = $_POST['nazwisko'];
$nzwFirmy = $_POST['nazwa_firmy'];
$NIPfirmy = $_POST['NIP_firmy'];
$telefon = $_POST['telefon'];
$email = $_POST['email'];
//Funkcjonalnosc strony
$responsywna = $_POST['responsywna'];
$chatFb = $_POST['chat'];
$socialMedia = $_POST['social_media'];
$sklepInternetowy = $_POST['sklep'];

$wersjeJezykowe = "";
$angielski = isset($_POST['wersjejezykoweAng']);
$niemiecki = isset($_POST['wersjejezykoweNiem']);
if(isset($_POST['wersjejezykoweAng'])){
    $wersjeJezykowe .= "Angielski";
} if(isset($_POST['wersjejezykoweNiem'])){
    $wersjeJezykowe .= ", ";
    $wersjeJezykowe .= "Niemiecki";
} else {
    $wersjeJezykowe = "Brak dodatkowych wersji jezykowych";
}


$ruchNaStronie = $_POST['ruch'];
//Twoja strona WWW
$adresStrony = $_POST['adres'];
$rodzajStrony = $_POST['rodzajstrony'];
//$logoStrony = $_POST['']; //plik
$iloscPodstron = $_POST['ilosc'];
$adresDomeny = $_POST['adres_domeny'];
$oprogramowanieStrony = $_POST['oprogramowanie'];
$nazwyZakladek = $_POST['nazwyzakladek'];
//Dodatkowe uslugi
$hostingDomeny = $_POST['hosting'];
$Serwer = $_POST['serwer'];
$towrzenieGrafik = $_POST['grafiki'];
$domena = $_POST['domena'];
$obrobkaMaterialow = $_POST['obrobka'];
//Dodatkowe informacje o stronie
$opisWygladu = $_POST['opiswygladu'];
$uwagi = $_POST['uwagi'];
$linkiDoStron = $_POST['linkidostron'];

//--------------------------------
/* ---PDF--- */ 
//--------------------------------

if(isset($_POST['pdf'])){

//Creating PDF
$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);

$pdf->SetTitle('Formularz Souczek Desing');

// set default header data
$pdf->SetHeaderData(NULL, NULL, "Formularz Souczek Design", NULL);

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

$pdf->AddPage('P', 'A4');

$content = <<<EOD
<h1> DANE FORMULARZA:</h1>
<h3> Dane Klienta </h3>
<h5> Imie: $imie </h5>
<h5> Nazwisko: $nazwisko </h5>
<h5> Nazwa firmy: $nzwFirmy </h5>
<h5> NIP firmy: $NIPfirmy </h5>
<h5> Telefon: $telefon </h5>
<h5> Adres email: $email </h5>

<h3> Funkcjonalnosc Strony </h3>
<h5> Responsywna: $responsywna </h5>
<h5> Chat Facebook: $chatFb </h5>
<h5> Social Media: $socialMedia </h5>
<h5> Sklep Internetowy: $sklepInternetowy </h5>
<h5> Wersje Jezykowe: $wersjeJezykowe </h5>
<h5> Ruch na stronie: $ruchNaStronie </h5>

<h3> Twoja strona WWW </h3>
<h5> Adres strony: $adresStrony </h5>
<h5> Rodzaj strony: $rodzajStrony </h5>
<h5> Ilosc podstron: $iloscPodstron </h5>
<h5> Adres domeny: $adresDomeny </h5>
<h5> Oprogramowanie strony: $oprogramowanieStrony </h5>
<h5> Nazwy zakladek: $nazwyZakladek </h5>

<h3> Dodatkowe Uslugi </h3>
<h5> Hosting domeny: $hostingDomeny </h5>
<h5> Zapewnienie serwera dla strony: $Serwer </h5>
<h5> Tworzenie grafiki: $towrzenieGrafik </h5>
<h5> Domena: $domena </h5>
<h5> Obrobka materialow: $obrobkaMaterialow </h5>

<h3> Dodatkowe informacje o stronie </h3>
<h5> Opis wygladu: <br> $opisWygladu </h5>
<h5> Dodatkowe uwagi: <br> $uwagi </h5>
<h5> Linki do stron: <br> $linkiDoStron </h5>
EOD;

$pdf->writeHTML($content);

//Download PDF
$pdf->Output('DaneFormularza.pdf','D');
}

//--------------------
/*---Mail---*/
//--------------------

$mail = new PHPMailer(true);

    try {
        //Server settings
        // $mail->SMTPDebug = 2;
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'rromanowski291@gmail.com';         //SMTP username
        $mail->Password   = 'tyghbn12#4';                       //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        //Recipients
        $mail->setFrom('testmail@gmail.com', 'Form');           //mail odbiorcy
        $mail->addAddress("19dg.nikodem.kwasniewski@ezse.pl", 'Mailer');

        //Attachments
        $mail->addStringAttachment($filledPdf, 'yourForm.pdf');

        //Content
        $mail->isHTML(true);
        $mail->Subject = "Here is your form $fname";
        $mail->Body    = "<b> Thank you for using our site! </b>";
        $mail->AltBody = 'Thank you for using our site!';

        $mail->send();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }

    include 'afterPage.html';