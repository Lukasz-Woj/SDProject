
var but = document.getElementById("but");

var cenaResponsywna = 200;
var cenaJezyk = 200;
var cenaSklepInternetowy = 200;
var cenaSocialMedia = 200;
var cenaChatFB = 200;
var cenaHosting = 200;
var cenaSerwer = 200;
var cenaGrafZaw = 200;
var cenaDomeny = 20000;
var cenaObrobka = 200;
var cenaPodstr = 200;

function obliczCene(){
	alert("hej");
	var cena = 0;
	cena += (parseInt(IloscPodstr.value) * cenaPodstr);
	
	if(RespTak.checked){
		cena += cenaResponsywna;
	}
	
	if(JezTak.checked){
		cena += (JezIlosc * cenaJezyk);
	}
	
	if(SklTak.checked){
		cena += cenaSklepInternetowy;
	}
	
	if(SocMedTak.checked){
		cena += cenaSocialMedia;
	}
	
	if(ChatTak.checked){
		cena += cenaChatFB;
	}
	
	if(HostTak.checked){
		cena += cenaHosting;
	}
	
	if(ServTak.checked){
		cena += cenaSerwer;
	}
	
	if(GrafTak.checked){
		cena += cenaGrafZaw;
	}
	
	if(DomTak.checked){
		cena += cenaDomeny;
	}
	
	if(ObrTak.checked){
		cena += cenaObrobka;
		
	}
	
	alert(cena);
}

but.onclick = obliczCene;
